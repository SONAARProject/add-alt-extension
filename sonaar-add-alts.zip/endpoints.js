/**
 * Change the endpoints to your local installation
 * These endpoints must use HTTPS
 */
const searchEndpoint = "http://localhost:3001/clarifai/search"; //"https://accessible-serv.lasige.di.fc.ul.pt/sonaar/clarifai/search";
const insertEndpoint = "http://localhost:3001/clarifai/insertBuffer"; //"https://accessible-serv.lasige.di.fc.ul.pt/sonaar/clarifai/insertBuffer";