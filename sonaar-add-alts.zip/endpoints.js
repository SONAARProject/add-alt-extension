/**
 * Change the endpoints to your local installation
 * These endpoints must use HTTPS
 */
const searchEndpoint = "https://accessible-serv.lasige.di.fc.ul.pt/sonaar/clarifai/search";
const insertEndpoint = "https://accessible-serv.lasige.di.fc.ul.pt/sonaar/clarifai/insertBuffer";